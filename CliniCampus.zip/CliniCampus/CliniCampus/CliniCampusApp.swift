//
//  CliniCampusApp.swift
//  CliniCampus
//
//  Created by found on 30/04/24.
//

import SwiftUI

@main
struct CliniCampusApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
