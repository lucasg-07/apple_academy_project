//
//  NoticiasView.swift
//  CliniCampus
//
//  Created by found on 10/05/24.
//

import SwiftUI

struct NoticiasView: View {
    var body: some View {
        Text("Noticias View")
    }
}

#Preview {
    NoticiasView()
}
