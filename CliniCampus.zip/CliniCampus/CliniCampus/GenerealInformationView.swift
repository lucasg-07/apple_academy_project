//
//  GenerealInformationView.swift
//  CliniCampus
//
//  Created by found on 03/05/24.
//
import SwiftUI

struct GenerealInformationView : View {
    var body: some View{
        Text("Sou uma tela")
    }
}

#Preview {
    GenerealInformationView()
}
