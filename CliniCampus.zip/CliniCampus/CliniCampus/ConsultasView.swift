//
//  ConsultasView.swift
//  CliniCampus
//
//  Created by found on 10/05/24.
//
import SwiftUI

struct ConsultasView: View {
    var body: some View {
        Text("Consultas")
    }
}
