//
//  PerfilView.swift
//  CliniCampus
//
//  Created by found on 10/05/24.
//

import SwiftUI

struct PerfilView: View {
    var body: some View {
        Text("Perfil View")
    }
}

#Preview {
    PerfilView()
}
